#ifndef __TIMER_H
#define __TIMER_H

 
void TIME_NVIC_Configuration(void);
void TIME_Configuration(void);
 
#endif